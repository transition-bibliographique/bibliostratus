# -*- coding: utf-8 -*-
"""
Created on Fri Oct 13 18:30:30 2017

@author: Etienne Cavalié

Programme de manipulations de données liées à la Transition bibliographique pour les bibliothèques françaises

"""

from lxml import etree
from urllib import request
import urllib.parse
from unidecode import unidecode
import urllib.error as error
import csv
import tkinter as tk
from tkinter import filedialog
from collections import defaultdict
import re
import webbrowser
import codecs
import json
import noticesbib2arkBnF as bib2ark
import noticesaut2arkBnF as aut2ark
import marc2tables as marc2tables
import ark2records as ark2records
import preferences
import funcs_gen as fg
import funcs_data as fd
import global_var as gl

#import matplotlib.pyplot as plt





def formulaire_main(access_to_network, last_version):
    couleur_fond = "white"
    couleur_bouton = "#e1e1e1"
    
    [master,
     zone_alert_explications,
     zone_access2programs,
     zone_actions,
     zone_ok_help_cancel,
     zone_notes] = fg.main_form_frames("Bibliostratus : Stratégie d'alignement d'URIs pour la Transition bibliographique",
                                      couleur_fond,
                                      couleur_bouton,access_to_network)
    
    frame1 = tk.Frame(zone_actions, highlightthickness=2, highlightbackground=couleur_bouton, bg=couleur_fond, pady=20, padx=20)
    frame1.pack(side="left",anchor="w")
    
    frame2 = tk.Frame(zone_actions, highlightthickness=0, highlightbackground=couleur_bouton, bg=couleur_fond, pady=20, padx=5)
    frame2.pack(side="left",anchor="w")
    
    frame3 = tk.Frame(zone_actions, highlightthickness=2, highlightbackground=couleur_bouton, bg=couleur_fond, pady=20, padx=20)
    frame3.pack(side="left")
    
    frame_help_cancel = tk.Frame(zone_ok_help_cancel, bg=couleur_fond, pady=10, padx=10)
    frame_help_cancel.pack()
    
# =============================================================================
#   Module blanc : aligner ses données bibliographiques ou AUT  
# =============================================================================
    tk.Label(frame1,text="Aligner ses données avec la BnF",bg=couleur_fond,fg="#365B43",font="Arial 11 bold").pack(anchor="w")
    tk.Label(frame1,text="\n",bg=couleur_fond).pack()

    bib2arkButton = tk.Button(frame1, text = "Aligner ses données  BIB\n avec le catalogue BnF\nà partir de fichiers tableaux", 
                              command=lambda: bib2ark.formulaire_noticesbib2arkBnF(master,access_to_network,[0,False]), 
                              padx=40,pady=47, bg="#fefefe", font="Arial 9 bold")
    bib2arkButton.pack()
    
    tk.Label(frame1,text="\n",bg=couleur_fond, font="Arial 3 normal").pack()
        
    aut2arkButton = tk.Button(frame1, text = "Aligner ses données AUT ", command=lambda: aut2ark.formulaire_noticesaut2arkBnF(master,access_to_network,[0,False]), 
                              padx=55,pady=25, bg="#fefefe", font="Arial 8 normal")
    aut2arkButton.pack()

    tk.Label(frame1,text="\n\n", bg=couleur_fond).pack()

    tk.Label(frame2,text="\n\n", bg=couleur_fond).pack()
# =============================================================================
#     Module bleu : convertir un fichier MARC en tables
# =============================================================================
    tk.Label(frame3,text="Outils d'accompagnement",bg=couleur_fond,
             fg="#365B43",font="Arial 11 bold").pack(anchor="w")
    tk.Label(frame3,text="\n",bg=couleur_fond,font="Arial 4 normal").pack()

    tk.Label(frame3,text="Avant alignement",bg=couleur_fond,
             fg="#2D4991",font="Arial 10 bold").pack(anchor="w")
    
    tk.Label(frame3,text="Préparer ses données",
             bg=couleur_fond,fg="#365B43",font="Arial 9 bold").pack(anchor="w")
    tk.Label(frame3,text="(constitution de tableaux\nà partir d'un export catalogue)",
             bg=couleur_fond,fg="#365B43",font="Arial 9 normal", justify="left").pack(anchor="w")
    
    
    marc2tableButton = tk.Button(frame3, text = "Convertir un fichier Unimarc\n en tableaux", 
                                 command=lambda: marc2tables.formulaire_marc2tables(master,access_to_network), 
                                 padx=10,pady=10, bg="#2D4991",fg="white")
    marc2tableButton.pack()
    
    #☺tk.Label(frame3,text="\n",bg=couleur_fond).pack()
    
    tk.Label(frame3, text="\n"+"-"*50, bg=couleur_fond,fg="#a1a1a1").pack()
# =============================================================================
#    Module rouge : exporter des notices à partir d'une liste d'ARK
# =============================================================================
    tk.Label(frame3,text="Après alignement",bg=couleur_fond,
             fg="#99182D",font="Arial 10 bold").pack(anchor="w")
    tk.Label(frame3,text="Exporter les données BnF après alignement",bg=couleur_fond,fg="#365B43",font="Arial 9 bold").pack(anchor="w")

    ark2recordsButton = tk.Button(frame3, text = "Exporter une liste d'ARK BnF\n en notices", 
                                  command=lambda: ark2records.formulaire_ark2records(master,access_to_network,[0,False]), 
                                  padx=10,pady=10, bg="#99182D", fg="white")
    ark2recordsButton.pack()

    tk.Label(frame3,text="\n",bg=couleur_fond, font="Arial 7 normal").pack()

    
    tk.Label(zone_ok_help_cancel,text=" ", pady=5, bg=couleur_fond).pack()
    

    call4help = tk.Button(frame_help_cancel,
                          text=gl.texte_bouton_help, 
                          command=lambda: fg.click2openurl(gl.url_online_help), 
                          pady=25, padx=5, width=12)
    call4help.pack()
    tk.Label(frame_help_cancel, text="\n",bg=couleur_fond, font="Arial 1 normal").pack()
    
    forum_button = tk.Button(frame_help_cancel, 
                          text=gl.texte_bouton_forum, 
                          command=lambda: fg.click2openurl(gl.url_forum_aide), 
                          pady=15, padx=5, width=12)
    forum_button.pack()
    
    tk.Label(frame_help_cancel, text="\n",bg=couleur_fond, font="Arial 8 normal").pack()
    cancel = tk.Button(frame_help_cancel, text="Annuler",bg=couleur_fond, command=lambda: fg.annuler(master), pady=45, padx=5, width=12)
    cancel.pack()



    tk.Label(zone_notes, text = "Bibliostratus - Version " + str(gl.version) + " - " + gl.lastupdate, bg=couleur_fond).pack()
    
    if (last_version[1] == True):
        download_update = tk.Button(zone_notes, text = "Télécharger la version " + str(last_version[0]), command=fg.download_last_update)
        download_update.pack()
        url_release_notes = "https://github.com/Transition-bibliographique/bibliostratus/blob/master/source/release_notes.md#" + "version-" + str(last_version[0]).replace(".","")
        release_notes = tk.Button(zone_notes, 
                                  bg=couleur_fond,
                                  font="Arial 8 bold italic",
                                  border=0,
                                  text = "Liste des nouveautés", 
                                  command=lambda: fg.download_last_update(url_release_notes)
                                  )
        release_notes.pack()
    
    tk.mainloop()
    

if __name__ == '__main__':
    access_to_network = fg.check_access_to_network()
    last_version = [0,False]
    if(access_to_network is True):
        last_version = fg.check_last_compilation(gl.programID)
    formulaire_main(access_to_network, last_version)
