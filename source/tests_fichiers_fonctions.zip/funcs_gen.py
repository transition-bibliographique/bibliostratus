# -*- coding: utf-8 -*-
"""
Created on Fri Oct 13 18:30:30 2017

@author: Etienne Cavalié

Programme de manipulations de données liées à la Transition bibliographique pour les bibliothèques françaises
funcs_gen : fonctions génériques liées au fonctionnement du programme

"""

from lxml import etree
from urllib import request
import urllib.parse
from unidecode import unidecode
import urllib.error as error
import csv
import tkinter as tk
from tkinter import filedialog
from collections import defaultdict
import re
import webbrowser
import codecs
import json
import noticesbib2arkBnF as bib2ark
import noticesaut2arkBnF as aut2ark
import marc2tables as marc2tables
import ark2records as ark2records
import preferences
import funcs_data as fd
import global_var as gl


def click2openurl(url):
    webbrowser.open(url)
def annuler(master):
    master.destroy()

def check_last_compilation(programID):
    programID_last_compilation = 0
    display_update_button = False
    url = "https://raw.githubusercontent.com/Transition-bibliographique/bibliostratus/master/source/last_compilations.json"
    try:
        last_compilations = request.urlopen(url)
        reader = codecs.getreader("utf-8")
        last_compilations = json.load(reader(last_compilations))["last_compilations"][0]
        if (programID in last_compilations):
            programID_last_compilation = last_compilations[programID]
        if (programID_last_compilation > gl.version):
            display_update_button = True
    except error.URLError:
        print("erreur réseau")
    return [programID_last_compilation,display_update_button]

def download_last_update(url="https://github.com/Transition-bibliographique/bibliostratus/tree/master/bin"):
    webbrowser.open(url)

def check_access_to_network():
    access_to_network = True
    try:
        request.urlopen("http://catalogue.bnf.fr/api")
    except error.URLError:
        print("Pas de réseau internet")
        access_to_network = False
    return access_to_network

def check_access2apis(i,dict_report):
    """Vérification de la disponibilité du SRU BnF et des API Abes
    (en supposant que si une requête d'exemple fonctionne, tout fonctionne"""
    testBnF = True
    testAbes = True
    testBnF = bib2ark.testURLretrieve("http://catalogue.bnf.fr/api/SRU?version=1.2&operation=searchRetrieve&query=bib.recordid%20all%20%2230000001%22&recordSchema=unimarcxchange&maximumRecords=20&startRecord=1")
    testAbes = bib2ark.testURLretrieve("https://www.sudoc.fr/services/isbn2ppn/0195141156")
    dict_report["testAbes"][i] = testAbes
    dict_report["testBnF"][i] = testBnF

def form_saut_de_ligne(frame, couleur_fond):
    tk.Label(frame, text="\n", bg=couleur_fond).pack()

def form_generic_frames(master,title, couleur_fond, couleur_bordure,access_to_network):
#----------------------------------------------------
#|                    Frame                         |
#|            zone_alert_explications               |
#----------------------------------------------------
#|                    Frame                         |
#|             zone_access2programs                 |
#|                                                  |
#|              Frame           |       Frame       |
#|           zone_actions       |  zone_help_cancel |
#----------------------------------------------------
#|                    Frame                         |
#|                  zone_notes                      |
#----------------------------------------------------
    #master = tk.Tk()
    form = tk.Toplevel(master)
    form.config(padx=10,pady=10,bg=couleur_fond)
    form.title(title)
    try:
        form.iconbitmap(r'favicon.ico')
    except tk.TclError:
        favicone = "rien"

    zone_alert_explications = tk.Frame(form, bg=couleur_fond, pady=10)
    zone_alert_explications.pack()
    
    zone_access2programs = tk.Frame(form, bg=couleur_fond)
    zone_access2programs.pack()
    zone_actions = tk.Frame(zone_access2programs, bg=couleur_fond)
    zone_actions.pack(side="left")
    zone_ok_help_cancel = tk.Frame(zone_access2programs, bg=couleur_fond)
    zone_ok_help_cancel.pack(side="left")
    zone_notes = tk.Frame(form, bg=couleur_fond, pady=10)
    zone_notes.pack()

    if (access_to_network == False):
        tk.Label(zone_alert_explications, text=errors["no_internet"], 
                 bg=couleur_fond,  fg="red").pack()

    
    return [form,
            zone_alert_explications,
            zone_access2programs,
            zone_actions,
            zone_ok_help_cancel,
            zone_notes]

def main_form_frames(title, couleur_fond, couleur_bordure,access_to_network):
#----------------------------------------------------
#|                    Frame                         |
#|            zone_alert_explications               |
#----------------------------------------------------
#|                    Frame                         |
#|             zone_access2programs                 |
#|                                                  |
#|              Frame           |       Frame       |
#|           zone_actions       |  zone_help_cancel |
#----------------------------------------------------
#|                    Frame                         |
#|                  zone_notes                      |
#----------------------------------------------------
    master = tk.Tk()
    master.config(padx=10,pady=10,bg=couleur_fond)
    master.title(title)
    try:
        master.iconbitmap(r'favicon.ico')
    except tk.TclError:
        favicone = "rien"

    zone_alert_explications = tk.Frame(master, bg=couleur_fond, pady=10)
    zone_alert_explications.pack()
    
    zone_access2programs = tk.Frame(master, bg=couleur_fond)
    zone_access2programs.pack()
    zone_actions = tk.Frame(zone_access2programs, bg=couleur_fond)
    zone_actions.pack(side="left")
    zone_ok_help_cancel = tk.Frame(zone_access2programs, bg=couleur_fond)
    zone_ok_help_cancel.pack(side="left")
    zone_notes = tk.Frame(master, bg=couleur_fond, pady=10)
    zone_notes.pack()

    if (access_to_network == False):
        tk.Label(zone_alert_explications, text=errors["no_internet"], 
                 bg=couleur_fond,  fg="red").pack()

    
    return [master,
            zone_alert_explications,
            zone_access2programs,
            zone_actions,
            zone_ok_help_cancel,
            zone_notes]


def radioButton_lienExample(frame,variable_button,val,couleur_fond,text1,text2,link):
    packButton = tk.Frame(frame, bg=couleur_fond)
    packButton.pack(anchor="w")
    line1 = tk.Frame(packButton, bg=couleur_fond)
    line1.pack(anchor="w")
    tk.Radiobutton(line1,bg=couleur_fond, 
                   text=text1, 
                   variable=variable_button, value=val, justify="left").pack(anchor="w", side="left")    
    if (link != ""):
        tk.Label(line1,text="  ",bg=couleur_fond).pack(anchor="w", side="left")
        example_ico = tk.Button(line1, bd=0, justify="left", font="Arial 7 underline",
                                    text="exemple", fg="#0000ff", bg=couleur_fond, command=lambda: click2openurl(link))
        example_ico.pack(anchor="w", side="left")
    if (text2 != ""):
        line2 = tk.Frame(packButton, bg=couleur_fond)
        line2.pack(anchor="w")
        tk.Label(line2, bg=couleur_fond, text="      "+text2, justify="left").pack(anchor="w")



def generic_input_controls(master,filename):
    check_file_name(master,filename)

def check_file_utf8(master, filename):
    try:
        open(filename, "r", encoding="utf-8")
    except FileNotFoundError:
        popup_errors(master,"Le fichier " + filename + " n'existe pas")
    except UnicodeDecodeError:
        popup_errors(master,errors["pb_input_utf8"])
        
       
def check_file_name(master,filename):
    try:
        open(filename,"r")
    except FileNotFoundError:
        popup_errors(master,"Le fichier " + filename + " n'existe pas")

def control_columns_number(master,row,headers_columns):
    """Vérifie le nombre de colonnes dans le fichier en entrée"""
    last_col = len(headers_columns)-1
    test= True
    try:
        last_val = row[last_col]
    except IndexError as err:
        test = False
    try:
        assert test
    except AssertionError:
        i = 0
        message = ""
        for col in headers_columns:
            val = ""
            if (len(row) >= i+1):
                val = row[i]
            message = message + col + " : " + val + "\n"
            i += 1
        message = errors["nb_colonnes_incorrect"] + "\n\n\nFormat attendu - Ligne 1 :\n\n" + message
        popup_errors(master,message)
    return test
        

def extract_cols_from_row(row,liste):
        nb_cols = len(row)
        i = 0
        liste_values = []
        for el in liste:
            if (i<nb_cols):
                liste_values.append(row[i])
            else:
                liste_values.append("")
            i += 1
        return tuple(liste_values)    

def popup_errors(master,text,online_help_text="",online_help_link=""):
    couleur_fond = "white"
    couleur_bordure = "red"
    [master,
            zone_alert_explications,
            zone_access2programs,
            zone_actions,
            zone_ok_help_cancel,
            zone_notes] = form_generic_frames(master,"Alerte", couleur_fond, couleur_bordure,True)
    tk.Label(zone_access2programs, text=text, fg=couleur_bordure, 
             font="bold", bg=couleur_fond, padx=20, pady=20).pack()
    if (online_help_text != ""):
        help_button = tk.Button(zone_access2programs, bd=2, justify="left", font="Arial 10 italic",
                                bg="#ffffff",
                                padx=5,pady=5,
                                    text=online_help_text, command=lambda: click2openurl(online_help_link))
        help_button.pack()
    tk.Label(zone_access2programs, bg=couleur_fond, text="\n").pack()
    cancel = tk.Button(zone_access2programs, text="Fermer", command=lambda: annuler(master), padx=10, pady=1, width=15)
    cancel.pack()

#popup_filename = ""
    
def openfile(frame,liste,background_color="white"):
    liste = []
    liste.append(filedialog.askopenfilename(title='Sélectionner un fichier'))
    filename_print = liste[0].split("/")[-1].split("\\")[-1]
    tk.Label(frame,text=filename_print, bg=background_color).pack()

def download_button(frame,text,frame_selected,text_path,couleur_fond,file_entry_list,zone_message_en_cours=""):
    if (file_entry_list != []):
        text_path.delete(0.0,1000.3)
    filename = filedialog.askopenfilename(parent=frame,title="Sélectionner un fichier")
    if (file_entry_list == []):
        file_entry_list.append(filename)
    else:
        file_entry_list[0] = filename
    text_path.insert(0.0,filename)
    texte = """Après avoir lancé le traitement,
vous pourrez suivre sa progression sur le terminal (fenêtre écran noir).
    
Cette fenêtre se fermera automatiquement à la fin du programme"""
    if (zone_message_en_cours != ""):
        zone_message_en_cours.insert(0.0,texte)
    
def download_zone(frame, text_bouton,file_entry_list,couleur_fond,cadre_output_message_en_cours=""):
    frame_button = tk.Frame(frame)
    frame_button.pack()
    frame_selected = tk.Frame(frame)
    frame_selected.pack()
    display_selected = tk.Text(frame_selected, height=3, width=50, bg=couleur_fond, bd=0, font="Arial 9 bold")
    display_selected.pack()
    zone_message_en_cours = ""
    if (cadre_output_message_en_cours != ""):
    #if (cadre_output_message_en_cours != "" and preferences["display_message_in_progress"]["value"]==1):
        zone_message_en_cours = tk.Text(cadre_output_message_en_cours, 
                                        height=5, width=70, fg="red",
                                        bg=couleur_fond, bd=0, font="Arial 9 bold")
        zone_message_en_cours.pack()
    #bouton_telecharger = download_button(frame,"Sélectionner un fichier","#ffffff")
    select_filename_button = tk.Button(frame_button,command=lambda:download_button(frame, 
                                                    text_bouton,
                                                    frame_selected,display_selected,
                                                    "#ffffff", file_entry_list,zone_message_en_cours),
                                text=text_bouton,
                                padx=10, pady=10)
    select_filename_button.pack()

def select_directory_button(frame,text,frame_selected,text_path,couleur_fond,directory_list):
    if (directory_list != []):
        text_path.delete(0.0,1000.3)
    filename = filedialog.askdirectory(parent=frame,title="Sélectionner un fichier")
    tk.folder_path.set(filename)
    if (directory_list == []):
        directory_list.append(filename)
    else:
        directory_list[0] = filename
    text_path.insert(0.0,filename)
    

def select_directory(frame, text_bouton,directory_list,couleur_fond):
    frame_button = tk.Frame(frame)
    frame_button.pack()
    frame_selected = tk.Frame(frame)
    frame_selected.pack()
    display_selected = tk.Text(frame_selected, height=3, width=50, bg=couleur_fond, bd=0, font="Arial 9 bold")
    display_selected.pack()
    #bouton_telecharger = download_button(frame,"Sélectionner un fichier","#ffffff")
    select_filename_button = tk.Button(frame_button,command=lambda:download_button(frame, 
                                                    text_bouton,
                                                    frame_selected,display_selected,
                                                    "#ffffff", directory_list),
                                text=text_bouton,
                                padx=10, pady=10)
    select_filename_button.pack()


def message_programme_en_cours(master, access_to_network=True, couleur_fond="#ffffff"):
    texte = """Le programme est en cours d'exécution.
Vous pouvez suivre sa progression sur le terminal (écran noir).
    
Cette fenêtre se fermera toute seule à la fin du programme
et sa fermeture signifiera que le programme est arrivée à la fin du traitement"""
    #zone_message.insert(0.0,texte)
    couleur_bouton = "#efefef"
    [form,
    zone_alert_explications,
    zone_access2programs,
    zone_actions,
    zone_ok_help_cancel,
    zone_notes] = form_generic_frames(master,"Traitement en cours",
                                      couleur_fond,couleur_bouton,
                                      access_to_network)
    a = tk.Label(zone_alert_explications, text=texte)
    a.pack()
    #form.mainloop()
    return form


def ark2url(ark, type_record, format_BIB):
    query = type_record + '.persistentid any "' + ark + '"'
    if (type_record == "aut"):
        query += ' and aut.status any "sparse validated"'
    query = urllib.parse.quote(query)
    url = "http://catalogue.bnf.fr/api/SRU?version=1.2&operation=searchRetrieve&query=" + query + "&recordSchema=" + format_BIB + "&maximumRecords=20&startRecord=1&origin=bibliostratus"
    return url

def nn2url(nn, type_record, format_BIB):
    query = type_record + '.recordid any "' + nn + '"'
    if (type_record == "aut"):
        query += ' and aut.status any "sparse validated"'
    query = urllib.parse.quote(query)
    url = "http://catalogue.bnf.fr/api/SRU?version=1.2&operation=searchRetrieve&query=" + query + "&recordSchema=" + format_BIB + "&maximumRecords=20&startRecord=1"
    return url

def ark2record(ark, type_record, format_BIB, renvoyerNotice=False):
    url = ark2url(ark, type_record, format_BIB)
    test = True
    try:
        page = etree.parse(request.urlopen(url))
    except error.URLerror:
        test = False
        print("Pb d'accès à la notice " + ark)
    if (test == True):
        record = page.xpath(".//srw:recordData/mxc:record",namespaces=main.ns)[0]
    if (renvoyerNotice == True):
        return record

def XMLrecord2string(record):
    record_str = str(etree.tostring(record))
    record_str = record_str.replace("b'","").replace("      '","\n").replace("\\n","\n").replace("\\t","\t").replace("\\r","\n")
    return (record_str)


def testURLetreeParse(url):
    test = True
    resultat = ""
    try:
        resultat = etree.parse(request.urlopen(url))
    except etree.XMLSyntaxError as err:
        print(url)
        print(err)
        url_access_pbs.append([url,"etree.XMLSyntaxError"])
        test = False
    except etree.ParseError as err:
        print(url)
        print(err)
        test = False
        url_access_pbs.append([url,"etree.ParseError"])
    except error.URLError as err:
        print(url)
        print(err)
        test = False
        url_access_pbs.append([url,"urllib.error.URLError"])
    except ConnectionResetError as err:
        print(url)
        print(err)
        test = False
        url_access_pbs.append([url,"ConnectionResetError"])
    except TimeoutError as err:
        print(url)
        print(err)
        test = False
        url_access_pbs.append([url,"TimeoutError"])
    except http.client.RemoteDisconnected as err:
        print(url)
        print(err)
        test = False
        url_access_pbs.append([url,"http.client.RemoteDisconnected"])
    except http.client.BadStatusLine as err:
        print(url)
        print(err)
        test = False
        url_access_pbs.append([url,"http.client.BadStatusLine"])
    except ConnectionAbortedError as err:
        print(url)
        print(err)
        test = False
        url_access_pbs.append([url,"ConnectionAbortedError"])
    return (test,resultat)


def testURLurlopen(url):
    test = True
    resultat = ""
    try:
        resultat = request.urlopen(url)
    except etree.XMLSyntaxError as err:
        print(url)
        print(err)
        url_access_pbs.append([url,"etree.XMLSyntaxError"])
        test = False
    except etree.ParseError as err:
        print(url)
        print(err)
        test = False
        url_access_pbs.append([url,"etree.ParseError"])
    except error.URLError as err:
        print(url)
        print(err)
        test = False
        url_access_pbs.append([url,"urllib.error.URLError"])
    except ConnectionResetError as err:
        print(url)
        print(err)
        test = False
        url_access_pbs.append([url,"ConnectionResetError"])
    except TimeoutError as err:
        print(url)
        print(err)
        test = False
        url_access_pbs.append([url,"TimeoutError"])
    except http.client.RemoteDisconnected as err:
        print(url)
        print(err)
        test = False
        url_access_pbs.append([url,"http.client.RemoteDisconnected"])
    except http.client.BadStatusLine as err:
        print(url)
        print(err)
        test = False
        url_access_pbs.append([url,"http.client.BadStatusLine"])
    except ConnectionAbortedError as err:
        print(url)
        print(err)
        test = False
        url_access_pbs.append([url,"ConnectionAbortedError"])
    return (test,resultat)

def testURLretrieve(url):
    test = True
    try:
        request.urlretrieve(url)
    except error.HTTPError as err:
        test = False
    except error.URLError as err:
        test = False
    except http.client.RemoteDisconnected as err:
        test = False
    except ConnectionAbortedError as err:
        test = False
    return test

def url_requete_sru(query,recordSchema="unimarcxchange",maximumRecords="1000",startRecord="1"):
    url = main.urlSRUroot + urllib.parse.quote(query) +"&recordSchema=" + recordSchema + "&maximumRecords=" + maximumRecords + "&startRecord=" + startRecord + "&origin=bibliostratus"
    return url

def fin_alignements(form,liste_reports,nb_notices_nb_ARK):
    stats_extraction(liste_reports,nb_notices_nb_ARK)
    url_access_pbs_report(liste_reports)
    check_access_to_apis(liste_reports)
    typesConversionARK(liste_reports)
    print("Programme terminé")
    form.destroy()
    for file in liste_reports:
        file.close()


